package "httpd"

service "httpd" do
  action [ :enable, :start ]
end
